
<?php $__env->startSection('content'); ?>
<div class="card-header mb-2">
    <div class="d-flex align-items-center">
        <h4 class="">Edit Akun <b><?php echo e($users->name); ?></b></h4>
    </div>
</div>
<hr class="horizontal dark">
<form action="<?php echo e(auth()->user()->role === 'admin' ? route('admin.edit.akun', $users->id) : ''); ?>" 
    method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Nama</label>
                      <input name="name" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->name); ?>">
                    </div>
                    <div class="mb-3">
                      <label for="exampleInputEmail1" class="form-label">Email</label>
                      <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" value="<?php echo e($users->email); ?>">
                    </div>
                    <div class="mb-3">
                    <label for="Role" class="form-label">Role</label>
                    <select name="role" id="role" class="form-control" required>
                        <option value="<?php echo e($users->role); ?>"><?php echo e($users->role); ?></option>
                        <option value="admin">Admin</option>
                        <option value="ustad">Ustad</option>
                        <option value="santri">Santri</option>
                    </select>
                    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('role'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('role')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/edit-akun.blade.php ENDPATH**/ ?>