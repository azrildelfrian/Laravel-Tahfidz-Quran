
<?php $__env->startSection('content'); ?>
Ini daftar setoran
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/daftar-setoran.blade.php ENDPATH**/ ?>