
<?php $__env->startSection('content'); ?>
<div class="table-responsive text-nowrap">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex px-2">
            <form class="mr-2" action="<?php echo e(url()->current()); ?>" method="GET">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari..." name="search" value="<?php echo e(request('search')); ?>">
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </form>
        </div>
        <div class="text-right">
            <form action="<?php echo e(url()->current()); ?>" method="GET" class="form-inline">
                <label for="per_page" class="mr-2">Show:</label>
                <select name="per_page" id="per_page" class="form-select mr-2" onchange="this.form.submit()">
                    <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($perPage); ?>" <?php echo e($perPage == $hafalan->perPage() ? 'selected' : ''); ?>>
                        <?php echo e($perPage); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </div>
    </div>
    <table class="table">
        <thead>
            <tr>
                <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'ustad'): ?>
                <th>Nama</th>
                <?php endif; ?>
                <th>Dari</th>
                <th>Sampai</th>
                <th>Tanggal</th>
                <th>Status</th>
                <th>Mengulang</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $hafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'ustad'): ?>
                <td>
                    <?php if($item->user->trashed()): ?>
                    <i class="fab fa-angular fa-lg text-danger me-3"></i>
                    <strong><?php echo e($item->user->name); ?></strong> <i>(Akun telah dihapus)</i>
                    <?php else: ?>
                    <i class="fab fa-angular fa-lg text-danger me-3"></i>
                    <strong><?php echo e($item->user->name); ?></strong>
                    <?php endif; ?>
                </td>
                <?php endif; ?>
                <td><?php echo e($item->surat_1->nama_surat); ?> Ayat <?php echo e($item->ayat_setoran_1); ?></td>
                <td> <?php echo e($item->surat_2->nama_surat); ?> Ayat <?php echo e($item->ayat_setoran_2); ?></td>
                <td><?php echo e($item->tanggal_hafalan); ?></td>
                <td>
                    <span class="badge 
                    <?php echo e($item->status === 'belum diperiksa' ? 'bg-warning' : 
                        ($item->status === 'sedang diperiksa' ? 'bg-primary' : 'bg-success')); ?>"><?php echo e($item->status); ?>

                    </span>
                </td>
                <td>
                    <?php if($item->ulang === 'mengulang' || $item->ulang === 'tidak'): ?>
                    <span class="badge 
                    <?php echo e($item->ulang === 'mengulang' ? 'bg-danger' : 
                        ($item->ulang === 'tidak' ? 'bg-primary' : 'bg-warning')); ?>"><?php echo e($item->ulang); ?>

                    </span>
                    <?php else: ?>
                    -
                    <?php endif; ?>
                </td>
                <td>
                    <?php if(auth()->user()->role === 'admin'): ?>
                    <div class="dropdown">
                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="ti ti-dots-vertical"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(route('admin.pages.detail-hafalan', $item->id)); ?>" class="dropdown-item bg-dark text-white">
                                <i class="ti ti-eye me-1"></i> Detail</a>
                            <a href="<?php echo e(route('admin.edit-hafalan', $item->id)); ?>" class="dropdown-item bg-warning text-white">
                                <i class="ti ti-edit me-1"></i> Edit</a>
                            <form action="<?php echo e(route('admin.daftar-hafalan.destroy', $item->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" id="delete_confirm" data-confirm-delete="true" class="dropdown-item bg-danger text-white show_confirm"><i class="ti ti-trash me-1"></i> Delete</button>
                            </form>
                        </div>
                    </div>
                    <?php elseif(auth()->user()->role === 'ustad'): ?>
                    <a href="<?php echo e(route('ustad.pages.detail-hafalan', $item->id)); ?>" class="btn btn-dark">Detail</a>
                    <?php elseif(auth()->user()->role === 'santri'): ?>
                    <a href="<?php echo e(route('pages.detail-hafalan', $item->id)); ?>" class="btn btn-dark">Detail</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="d-flex justify-content-between">
    <div class="text-left">
        <p class="text-sm text-gray-700 leading-5">
            Showing
            <span class="font-medium"><?php echo e($hafalan->firstItem()); ?></span>
            to
            <span class="font-medium"><?php echo e($hafalan->lastItem()); ?></span>
            of
            <span class="font-medium"><?php echo e($hafalan->total()); ?></span>
            results
        </p>
    </div>
    <div class="text-right">
        <?php echo e($hafalan->appends(request()->input())->links()); ?>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/daftar-hafalan.blade.php ENDPATH**/ ?>