
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">Detail Hafalan</h5>
                    <div class="row">
                    <div class="col-md-4">
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Nama Santri</label>
                      <?php if($hafalan->user->trashed()): ?>
                          <p><strong><?php echo e($hafalan->user->name); ?></strong> <i>(Akun telah dihapus)</i></p>
                      <?php else: ?>
                          <p><strong><?php echo e($hafalan->user->name); ?></strong></p>
                      <?php endif; ?>
                    </div>
                    <div class="mb-3">
                      <label for="Surat" class="form-label">Surat Hafalan</label>
                      <p><?php echo e($hafalan->surat_1->nama_surat); ?> Ayat <?php echo e($hafalan->ayat_setoran_1); ?></p>
                      <p>Sampai</p>
                      <p><?php echo e($hafalan->surat_2->nama_surat); ?> Ayat <?php echo e($hafalan->ayat_setoran_2); ?></p>
                    </div>
                    </div>
                    <div class="col-md-4">
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Status</label>
                      <?php if($hafalan->status === 'sudah diperiksa'): ?>
                      <p>Sudah Diperiksa</p>
                      <?php elseif($hafalan->status === 'belum diperiksa'): ?>
                      <p>Belum Diperiksa</p>
                      <?php else: ?>
                      <p>-</p>
                      <?php endif; ?>
                    </div>
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Kelancaran</label>
                      <?php if($hafalan->kelancaran): ?>
                      <p><?php echo e($hafalan->kelancaran); ?></p>
                      <?php else: ?>
                      <p>-</p>
                      <?php endif; ?>
                    </div>
                    </div>
                    <div class="col-md-4">
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Tanggal Hafalan</label>
                      <?php if($hafalan->tanggal_hafalan): ?>
                      <p><?php echo e($hafalan->tanggal_hafalan); ?></p>
                      <?php else: ?>
                      <p>-</p>
                      <?php endif; ?>
                    </div>
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Mengulang</label>
                      <?php if($hafalan->ulang): ?>
                      <p><?php echo e($hafalan->ulang); ?></p>
                      <?php else: ?>
                      <p>-</p>
                      <?php endif; ?>
                    </div>
                    <div class="mb-3">
                      <label for="NamaSantri" class="form-label">Diperiksa Oleh</label>
                      <?php if($hafalan->ustad): ?>
                      <p><?php echo e($hafalan->ustad->name); ?></p>
                      <?php else: ?>
                      <p>-</p>
                      <?php endif; ?>
                    </div>
                    </div>
                    <h6>File Hafalan</h6>
                        <?php if(isset($hafalan) && $hafalan->file_hafalan): ?>
                            <audio controls>
                                <source src="<?php echo e(asset('file/hafalan/' . $hafalan->file_hafalan)); ?>" type="audio/mpeg">
                                Your browser does not support the audio element.
                            </audio>
                        <?php else: ?>
                            <p>Tidak ada file hafalan</p>
                        <?php endif; ?>
                    </div>
                    <div class="mb-3">
                    <label for="NamaSantri" class="form-label">Catatan</label>
                    <div class="p-3 bg-light-primary rounded">
                      <?php if($hafalan->catatan_teks): ?>
                      <p><?php echo e($hafalan->catatan_teks); ?></p>
                      <?php else: ?>
                          <p>Belum ada catatan...</p>
                      <?php endif; ?>
                      <?php if($hafalan->catatan_suara): ?>
                          <audio controls>
                              <source src="<?php echo e(asset('file/catatan_suara/' . $hafalan->catatan_suara)); ?>" type="audio/mp3">
                              Your browser does not support the audio element.
                          </audio>
                      <?php endif; ?>
                    </div>
                    </div>
                    <?php if(auth()->user()->role === 'admin'): ?>
                        <?php if($hafalan->status === 'belum diperiksa' || $hafalan->status === 'sedang diperiksa'): ?>
                            <a href="<?php echo e(route('admin.pages.periksa-hafalan', $hafalan->id)); ?>" class="btn btn-warning">Periksa</a>
                            <!-- <a href="<?php echo e(url('/admin/daftar-hafalan')); ?>" class="btn btn-primary">Kembali</a> -->
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.edit-hafalan', $hafalan->id)); ?>" class="btn btn-success">Edit</a>
                        <a href="<?php echo e(url('/admin/daftar-hafalan')); ?>" class="btn btn-primary">Kembali</a>
                        <!-- <button class="btn btn-primary" onclick="goBack()">Kembali</button> -->
                    <?php elseif(auth()->user()->role === 'ustad'): ?>
                        <?php if($hafalan->status === 'belum diperiksa' || $hafalan->status === 'sedang diperiksa'): ?>
                            <a href="<?php echo e(route('ustad.pages.periksa-hafalan', $hafalan->id)); ?>" class="btn btn-warning">Periksa</a>
                        <?php endif; ?>
                        <a href="<?php echo e(url('/ustad/daftar-hafalan')); ?>" class="btn btn-primary">Kembali</a>
                        <!-- <button class="btn btn-primary" onclick="goBack()">Kembali</button> -->
                    <?php elseif(auth()->user()->role === 'santri'): ?>
                        <?php if($hafalan->ulang === 'mengulang'): ?>
                            <a href="<?php echo e(route('pages.edit-hafalan', $hafalan->id)); ?>" class="btn btn-warning">Revisi</a>
                        <?php endif; ?>
                        <!-- <button class="btn btn-primary" onclick="goBack()">Kembali</button> -->
                        <a href="<?php echo e(url('/daftar-hafalan')); ?>" class="btn btn-primary">Kembali</a>
                    <?php endif; ?>
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
function goBack() {
  window.history.back();
}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/detail-hafalan.blade.php ENDPATH**/ ?>