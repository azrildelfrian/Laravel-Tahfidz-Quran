
<?php $__env->startSection('content'); ?>
<div class="table-responsive text-nowrap">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="d-flex">
            <form class="mr-2" action="<?php echo e(url()->current()); ?>" method="GET">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Cari..." name="search" value="<?php echo e(request('search')); ?>">
                    <button class="btn btn-outline-secondary" type="submit">Cari</button>
                </div>
            </form>
            <a href="<?php echo e(route('pages.tambah-santri')); ?>" class="btn btn-primary mx-2">Tambah santri</a>
        </div>
        <div class="text-right">
            <form action="<?php echo e(url()->current()); ?>" method="GET" class="form-inline">
                <label for="per_page" class="mr-2">Show:</label>
                <select name="per_page" id="per_page" class="form-select mr-2" onchange="this.form.submit()">
                    <?php $__currentLoopData = [10, 25, 50, 100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perPage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($perPage); ?>" <?php echo e($perPage == $santri->perPage() ? 'selected' : ''); ?>>
                        <?php echo e($perPage); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </form>
        </div>
    </div>
    <table class="table" border="1">
        <thead>
            <tr>
                <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'ustad'): ?>
                <th>Nama</th>
                <?php endif; ?>
                <th>Email</th>
                <th>Halaqoh</th>
                <th>Nomor Induk</th>
                <th>Tanggal Dibuat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody class="table-border-bottom-0">
            <?php $__currentLoopData = $santri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <?php if(Auth::user()->role === 'admin' || Auth::user()->role === 'ustad'): ?>
                <td><i class="fab fa-angular fa-lg text-danger me-3"></i> <strong><?php echo e($item->user->name); ?></strong></td>
                <?php endif; ?>
                <td><?php echo e($item->user->email); ?></td>
                <td><?php echo e($item->halaqoh->nama_halaqoh); ?></td>
                <td><?php echo e($item->nomor_id); ?></td>
                <td><?php echo e($item->created_at); ?></td>
                <td>
                    <div class="dropdown">
                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                            <i class="ti ti-dots-vertical"></i>
                        </button>
                        <div class="dropdown-menu">
                            <a href="<?php echo e(route('admin.edit-santri', $item->id)); ?>" class="dropdown-item bg-warning text-white">
                                <i class="ti ti-edit me-1"></i> Edit</a>
                            <form action="<?php echo e(route('admin.delete.santri', $item->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" id="delete_confirm" data-confirm-delete="true" class="dropdown-item bg-danger text-white"><i class="ti ti-trash me-1"></i> Delete</button>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="d-flex justify-content-between">
    <div class="text-left">
        <p class="text-sm text-gray-700 leading-5">
            Showing
            <span class="font-medium"><?php echo e($santri->firstItem()); ?></span>
            to
            <span class="font-medium"><?php echo e($santri->lastItem()); ?></span>
            of
            <span class="font-medium"><?php echo e($santri->total()); ?></span>
            results
        </p>
    </div>
    <div class="text-right">
        <?php echo e($santri->appends(request()->input())->links()); ?>

    </div>
</div>

<script>
    function goBack() {
        window.history.back();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/daftar-santri.blade.php ENDPATH**/ ?>