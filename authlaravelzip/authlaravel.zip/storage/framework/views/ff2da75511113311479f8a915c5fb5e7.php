

<?php $__env->startSection('content'); ?>
  <form method="POST" action="<?php echo e(route('admin.kelas.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
      <label for="exampleInputName" class="form-label">Nama</label>
      <input type="text" name="kelas" class="form-control" id="exampleInputName" aria-describedby="nameHelp" placeholder="Masukkan nama kelas" required>
    </div>

    <a href="<?php echo e(url('/admin/daftar-kelas/')); ?>" class="btn btn-dark">Kembali</a>
    <button type="submit" class="btn btn-primary">Simpan</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/tambah-kelas.blade.php ENDPATH**/ ?>