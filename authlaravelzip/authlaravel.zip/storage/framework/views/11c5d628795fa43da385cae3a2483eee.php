

<?php $__env->startSection('content'); ?>
  <form method="POST" action="<?php echo e(route('admin.halaqoh.store')); ?>">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
      <label for="exampleInputName" class="form-label">Nama</label>
      <input type="text" name="nama_halaqoh" class="form-control" id="exampleInputName" aria-describedby="nameHelp" placeholder="Masukkan nama halaqoh" required>
    </div>

    <div class="mb-3">
        <label for="Pengampu" class="form-label">Ustad Pengampu</label>
        <select name="ustad_pengampu" id="nama_ustad" class="form-control" required>
            <option value="">=== Silahkan Pilih Ustad Pengampu ===</option>
            <?php $__currentLoopData = $ustads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item->role === 'ustad'): ?>
                <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <a href="<?php echo e(url('/admin/daftar-halaqoh/')); ?>" class="btn btn-dark">Kembali</a>
    <button type="submit" class="btn btn-primary">Simpan</button>
  </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\authlaravel\resources\views/pages/tambah-halaqoh.blade.php ENDPATH**/ ?>